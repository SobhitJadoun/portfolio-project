# V2 build & deployment checklist

## Delivered in this iteration

- [x] Preserve all existing portfolio sections, visual projects and original 3D hero.
- [x] Add a 4-phase, pinned, reversible construction demo synchronized to scroll position.
- [x] Five independently moving virtual cursors, each with its own role/color/trajectory.
- [x] Blueprint grid, selection bounds/handles, code tags, progressive typography, artwork and project cards.
- [x] Source-grounded GitHub projects gallery with direct repositories, with second account separated as a security archive.
- [x] Direct main GitHub, second GitHub and LinkedIn links, including in contact footer.
- [x] Add verified Deftsoft and MCA professional details without deleting the original introduction.
- [x] Change mail composition to the public contact email shown in the GitHub profile README.
- [x] JavaScript syntax checks and Chromium runtime interaction tests.

## Quality and launch follow-up

1. Compare the motion sequence frame by frame against the original reference recording. The video alone does not provide the original animation's precise timing, geometry or source assets; this is an original interactive recreation, not an exact copy.
2. Test on a physical iPhone and Android device, plus Safari, Firefox, Chrome, and Edge (especially WebGL availability and low-end scrolling).
3. Verify actual repository/attribution information, replace generalized project cards with screenshots and descriptions approved for public marketing.
4. Add proper contact submission backend (optional), captcha, anti-spam, and notification/CRM flow. Mailto is not a backend.
5. Compress & cache assets, run Lighthouse mobile/desktop reports, and monitor long-task and frame-rate traces during Scroll Build.
6. Verify legal reuse rights for any external imagery/assets added later. Current construction art and cursor overlays are custom HTML/CSS/JS.
7. Deploy and run keyboard navigation, reduced-motion, responsive breakpoints and screen reader smoke tests.
