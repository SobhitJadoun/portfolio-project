/* Pure WebGL interactive 3D ribbon-knot. No framework, CDN or paid assets required.
   Optimized to pause off-screen and honor reduced motion preferences. */
(() => {
  const canvas = document.getElementById('webglCanvas');
  const fallback = document.getElementById('webglFallback');
  if (!canvas) return;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let gl;
  try { gl = canvas.getContext('webgl', {alpha:true, antialias:true, powerPreference:'default'}); } catch (_) {}
  const fail = () => {canvas.style.display='none'; fallback.style.display='block';};
  if (!gl) { fail(); return; }
  const VERT = `
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute float aPhase;
  uniform mat4 uMVP;
  uniform mat4 uModel;
  varying vec3 vNormal;
  varying vec3 vWorld;
  varying float vPhase;
  void main(){
    vec4 pos = uModel * vec4(aPosition,1.0);
    vWorld = pos.xyz;
    vNormal = mat3(uModel)*aNormal;
    vPhase = aPhase;
    gl_Position = uMVP * vec4(aPosition,1.0);
  }`;
  const FRAG = `
  precision highp float;
  varying vec3 vNormal;
  varying vec3 vWorld;
  varying float vPhase;
  uniform float uTime;
  uniform float uPalette;
  void main(){
    vec3 N = normalize(vNormal);
    vec3 V = normalize(vec3(0.0,0.0,7.5)-vWorld);
    vec3 L = normalize(vec3(-0.55,0.8,1.3));
    float diff = max(dot(N,L),0.0);
    float diffuse2 = max(dot(N, normalize(vec3(1.0,-0.6,-0.7))),0.0);
    vec3 H = normalize(L+V);
    float spec = pow(max(dot(N,H),0.0),72.0);
    float fresnel = pow(1.0-max(dot(N,V),0.0),2.45);
    float variation = .5+.5*sin(vPhase*14.0 + .25*sin(uTime*.4));
    vec3 base;
    if(uPalette<.5){
      base=mix(vec3(.68,.59,1.0),vec3(.80,1.0,.42),smoothstep(.26,.74,variation));
    }else if(uPalette<1.5){
      base=mix(vec3(.42,.39,.80),vec3(.79,.66,1.0),variation);
    }else{
      base=vec3(.77,1.0,.54);
    }
    float metallic=.22+.85*diff+.25*diffuse2;
    vec3 col=base*metallic;
    col+=vec3(1.,1.,.88)*spec*1.2;
    col+=base*fresnel*.72;
    col+=base*pow(1.0-max(dot(N,V),0.0),5.0)*.24;
    gl_FragColor=vec4(pow(col,vec3(.92)),1.0);
  }`;
  function compile(type, code){const shader=gl.createShader(type);gl.shaderSource(shader,code);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;}
  let program;
  try {
    program=gl.createProgram();
    gl.attachShader(program,compile(gl.VERTEX_SHADER,VERT));
    gl.attachShader(program,compile(gl.FRAGMENT_SHADER,FRAG));
    gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
  } catch(e){console.warn('WebGL unavailable:',e);fail();return;}
  gl.useProgram(program);
  const loc={pos:gl.getAttribLocation(program,'aPosition'),norm:gl.getAttribLocation(program,'aNormal'),phase:gl.getAttribLocation(program,'aPhase'),mvp:gl.getUniformLocation(program,'uMVP'),model:gl.getUniformLocation(program,'uModel'),time:gl.getUniformLocation(program,'uTime'),pal:gl.getUniformLocation(program,'uPalette')};
  const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
  const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
  const norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l)};
  const sub=(a,b)=>a.map((v,i)=>v-b[i]);
  const add=(a,b)=>a.map((v,i)=>v+b[i]);
  const scale=(a,s)=>a.map(v=>v*s);
  const TWO=Math.PI*2;
  function point(t,p=2,q=3,rad=1.16){let r=rad+.39*Math.cos(q*t);return [r*Math.cos(p*t),r*Math.sin(p*t),.53*Math.sin(q*t)];}
  function makeKnot(p,q,radius,tube,segments=320,sides=18){
    const vertices=[],indices=[];
    for(let i=0;i<=segments;i++){
      const t=i/segments*TWO;
      const c=point(t,p,q,radius);
      const tangent=norm(sub(point(t+.001,p,q,radius),point(t-.001,p,q,radius)));
      let a=norm(cross(tangent,[0,0,1]));
      if(Math.hypot(...a)<.1)a=norm(cross(tangent,[0,1,0]));
      const b=norm(cross(tangent,a));
      for(let j=0;j<=sides;j++){
        const ang=j/sides*TWO;
        const normal=norm(add(scale(a,Math.cos(ang)),scale(b,Math.sin(ang))));
        const v=add(c,scale(normal,tube*(1+.055*Math.sin(t*17))));
        vertices.push(...v,...normal,i/segments);
        if(i<segments && j<sides){const off=i*(sides+1)+j;indices.push(off,off+sides+1,off+1,off+1,off+sides+1,off+sides+2);}
      }
    }
    const vertexBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vertexBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
    const indexBuffer=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,indexBuffer);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices),gl.STATIC_DRAW);
    return {vertexBuffer,indexBuffer,count:indices.length};
  }
  function makeTorus(major,tube,seg=160,sides=12){
    const verts=[],indices=[];
    for(let i=0;i<=seg;i++){
      const t=i/seg*TWO;
      for(let j=0;j<=sides;j++){
        const v=j/sides*TWO,co=Math.cos(v),si=Math.sin(v);
        const n=[Math.cos(t)*co,Math.sin(t)*co,si];
        verts.push((major+tube*co)*Math.cos(t),(major+tube*co)*Math.sin(t),tube*si,...n,i/seg);
        if(i<seg&&j<sides){let k=i*(sides+1)+j;indices.push(k,k+sides+1,k+1,k+1,k+sides+1,k+sides+2);}
      }
    }
    const vb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(verts),gl.STATIC_DRAW);
    const ib=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices),gl.STATIC_DRAW);
    return {vertexBuffer:vb,indexBuffer:ib,count:indices.length};
  }
  const knot=makeKnot(2,3,1.12,.25), ring=makeTorus(1.85,.05), halo=makeTorus(1.55,.025);
  const identity=()=>[1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1];
  const mul=(a,b)=>{let o=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];return o;};
  const rotX=a=>{let c=Math.cos(a),s=Math.sin(a);return [1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]};
  const rotY=a=>{let c=Math.cos(a),s=Math.sin(a);return [c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]};
  const rotZ=a=>{let c=Math.cos(a),s=Math.sin(a);return [c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1]};
  const sc=s=>[s,0,0,0,0,s,0,0,0,0,s,0,0,0,0,1];
  const translation=z=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,z,1];
  const perspective=(fov,aspect,near,far)=>{const f=1/Math.tan(fov/2),z=1/(near-far);return [f/aspect,0,0,0, 0,f,0,0, 0,0,(far+near)*z,-1, 0,0,2*far*near*z,0];};
  let pointer={x:0,y:0,tx:0,ty:0};let dragging=false,lastX=0,lastY=0,dragX=0,dragY=0;
  canvas.addEventListener('pointermove',e=>{const r=canvas.getBoundingClientRect();pointer.tx=((e.clientX-r.left)/r.width-.5)*2;pointer.ty=((e.clientY-r.top)/r.height-.5)*2;if(dragging){dragX+=(e.clientX-lastX)*.006;dragY+=(e.clientY-lastY)*.006;lastX=e.clientX;lastY=e.clientY;}});
  canvas.addEventListener('pointerleave',()=>{pointer.tx=0;pointer.ty=0;dragging=false;});
  canvas.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;try{canvas.setPointerCapture(e.pointerId)}catch(_){}});
  canvas.addEventListener('pointerup',()=>dragging=false);canvas.addEventListener('pointercancel',()=>dragging=false);
  let visible=true,frame=0,prev=0,elapsed=0;
  if('IntersectionObserver' in window){new IntersectionObserver(entries=>{visible=entries[0].isIntersecting},{threshold:0}).observe(canvas);}
  function resize(){const r=canvas.getBoundingClientRect();const dpr=Math.min(window.devicePixelRatio||1,1.6);const w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round(r.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}gl.viewport(0,0,w,h);}
  function draw(mesh,palette,model,projection){
    gl.bindBuffer(gl.ARRAY_BUFFER,mesh.vertexBuffer);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,mesh.indexBuffer);
    const stride=7*4;
    gl.enableVertexAttribArray(loc.pos);gl.vertexAttribPointer(loc.pos,3,gl.FLOAT,false,stride,0);
    gl.enableVertexAttribArray(loc.norm);gl.vertexAttribPointer(loc.norm,3,gl.FLOAT,false,stride,3*4);
    gl.enableVertexAttribArray(loc.phase);gl.vertexAttribPointer(loc.phase,1,gl.FLOAT,false,stride,6*4);
    gl.uniformMatrix4fv(loc.model,false,new Float32Array(model));
    gl.uniformMatrix4fv(loc.mvp,false,new Float32Array(mul(projection,model)));
    gl.uniform1f(loc.pal,palette);
    gl.drawElements(gl.TRIANGLES,mesh.count,gl.UNSIGNED_SHORT,0);
  }
  function render(now){
    frame=requestAnimationFrame(render);
    if(document.hidden||!visible)return;
    const delta=Math.min((now-prev)/1000||.016,.05);prev=now;
    if(!reduceMotion)elapsed+=delta;
    pointer.x+=(pointer.tx-pointer.x)*.035;pointer.y+=(pointer.ty-pointer.y)*.035;
    resize();gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform1f(loc.time,elapsed);
    const base=mul(rotY(.46+elapsed*.15+pointer.x*.22+dragX),mul(rotX(-.38+pointer.y*.18+dragY),rotZ(.13+elapsed*.11)));
    const aspect=canvas.width/canvas.height,projection=mul(perspective(Math.PI/3.5,aspect,.1,100),translation(-5.6));
    const s=window.innerWidth<720?.83:1.0;
    draw(ring,1,mul(base,mul(rotX(1.05),sc(s))),projection);
    draw(halo,2,mul(base,mul(rotY(.7),mul(rotX(1.5),sc(s)))),projection);
    draw(knot,0,mul(base,sc(s)),projection);
  }
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(frame);fail();});
  requestAnimationFrame(render);
})();
