# Premium Creative Developer Portfolio — V1

**Made for Sobhit Jadoun.** Original custom visual design, not a copy of another site's assets, text or source code.

## Preview immediately
Open `index.html` in Chrome, Edge, Firefox or Safari. No npm install, API keys or package downloads are required. For best local behavior, run a static server:

```bash
cd hex-portfolio
python3 -m http.server 8080
# Visit http://localhost:8080
```

## Before publishing
1. Change the `<title>`, meta description and content in `index.html` if needed.
2. In `assets/app.js`, set `CONFIG.contactEmail` to your real email to prepare enquiries in the visitor's email client. **Demo mode does not send messages.** For reliable actual sending, integrate a mail API/server handler separately.
3. Replace the `data-placeholder-link` GitHub and LinkedIn links with real personal URLs and remove those attributes.
4. Replace illustrative/ongoing project stories with verified outcomes and screenshots before claiming completed work.
5. Optionally customize palette via CSS variables at the top of `assets/styles.css`.
6. Deploy the static folder directly to any static hosting provider (GitHub Pages, Netlify, Cloudflare Pages, or Vercel static).

## Files
- `index.html` — markup, accessible sections, case study drawer
- `assets/styles.css` — typography, layouts, illustrations and responsive design
- `assets/webgl.js` — interactive raw WebGL 3D sculpture and shader program
- `assets/app.js` — animations, menu, drawer, accordion and contact behavior
- `IMPLEMENTATION_PLAN.md` — follow-on roadmap and QA checklist

## Technology
HTML, CSS, native JavaScript, WebGL, CSS and IntersectionObserver animations; system fonts with local fallbacks. No third-party JavaScript dependency. The abstract 3D object is actual shader-lit WebGL geometry and responds to mouse/touch drag.

## Browser notes
- Canvas graphics are decorative and have a static fallback when unavailable.
- Scene rendering pauses if not visible, and respects reduced-motion preferences.
- This first build has not been tested on every production browser. Do that before launch.
