/* Scroll-directed collaborative design simulation. Fully deterministic, reversible,
   dependency-free and separate from the real mouse cursor. */
(() => {
  'use strict';
  const story=document.getElementById('build');
  if(!story) return;
  const stage=document.getElementById('buildStage');
  const pieces=[...story.querySelectorAll('[data-build-at]')];
  const cursors=[...story.querySelectorAll('.build-cursor')];
  const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const steps=[
    ['01 / 04','Lay the foundations.','A layout grid and structural regions take shape.','STRUCTURE MODE','01 / DOCUMENT STRUCTURE'],
    ['02 / 04','Make the type speak.','Typography and narrative content flow into the frame.','CONTENT MODE','02 / TYPOGRAPHY + CONTENT'],
    ['03 / 04','Add movement & detail.','Visual assets, interactions and project cards come online.','MOTION MODE','03 / COMPONENTS + MOTION'],
    ['04 / 04','Ready for the world.','The finished page is assembled. Rewind by scrolling back.','PUBLISHED / LIVE','04 / READY TO EXPLORE']
  ];
  const paths=[
    [[10,12],[24,15],[57,12],[15,29],[48,30],[17,57],[24,72],[76,87],[46,94]],
    [[83,12],[75,22],[47,23],[30,37],[20,54],[68,54],[70,75],[58,83],[79,90]],
    [[15,88],[23,76],[29,55],[25,36],[13,41],[48,48],[33,25],[40,76],[51,69]],
    [[89,74],[86,61],[75,45],[75,31],[88,28],[70,47],[55,56],[64,79],[84,39]],
    [[52,92],[41,81],[83,79],[59,69],[34,66],[26,85],[80,90],[20,17],[87,15]]
  ];
  const $=id=>document.getElementById(id);
  let lastPhase=-1;
  let lastP=-1;
  function clamp(v){return Math.max(0,Math.min(1,v));}
  function smooth(t){return t*t*(3-2*t);}
  function calc(){
    const bounds=story.getBoundingClientRect();
    const travel=Math.max(1,bounds.height-window.innerHeight);
    return clamp(-bounds.top/travel);
  }
  function animate(p){
    if(Math.abs(p-lastP)<.00025) return;
    lastP=p;
    const phase=Math.min(3,Math.floor(p*4));
    stage.dataset.phase=String(phase);
    if(phase!==lastPhase){
      lastPhase=phase;
      $('buildStepNum').textContent=steps[phase][0];
      $('buildStepTitle').textContent=steps[phase][1];
      $('buildStepBody').textContent=steps[phase][2];
      $('buildMode').textContent=steps[phase][3];
      $('buildFootText').textContent=steps[phase][4];
    }
    $('buildPercent').textContent=String(Math.round(p*100)).padStart(2,'0')+'%';
    $('buildProgressFill').style.width=(p*100).toFixed(2)+'%';
    pieces.forEach(el=>el.classList.toggle('is-built',p >= Number(el.dataset.buildAt)));
    if(reduceMotion) return;
    cursors.forEach((el,i)=>{
      const path=paths[i];
      const at=p*(path.length-1);
      const a=Math.min(path.length-2,Math.floor(at));
      const t=smooth(at-a);
      const x=path[a][0]+(path[a+1][0]-path[a][0])*t;
      const y=path[a][1]+(path[a+1][1]-path[a][1])*t;
      el.style.left=x.toFixed(2)+'%';
      el.style.top=y.toFixed(2)+'%';
      el.style.transform=`rotate(${(Math.sin(p*24+i)*9).toFixed(2)}deg)`;
    });
    const angle=(-3+p*3).toFixed(2);
    const tilt=(2-p*2).toFixed(2);
    const browser=$('buildBrowser');
    if(innerWidth>720) browser.style.transform=`rotateY(${angle}deg) rotateX(${tilt}deg)`;
  }
  let rafId=0;
  function request(){if(rafId)return;rafId=requestAnimationFrame(()=>{rafId=0;animate(calc());});}
  if(reduceMotion){animate(1);story.querySelectorAll('.build-piece').forEach(el=>el.classList.add('is-built'));stage.dataset.phase='3';$('buildPercent').textContent='100%';}
  else{animate(calc());addEventListener('scroll',request,{passive:true});addEventListener('resize',request,{passive:true});addEventListener('pageshow',request);}
})();
