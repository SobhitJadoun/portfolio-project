/*
  REAL SITE CONSTRUCTION ENGINE — every selected real DOM element receives a
  deterministic, scroll-reversible build timeline. Five independent simulated
  collaborator cursors visit the elements, draw blue selection outlines, and
  reveal actual content, rather than animating a separate mock website.
  Graceful degradation: requires JS + CSS; reduced motion uses static website.
*/
(() => {
  'use strict';
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const layer = document.getElementById('siteConstructionLayer');
  if (!layer || !document.getElementById('top')) return;
  const root = document.documentElement;
  const palettes = ['#6cadff','#d5ff72','#ff8277','#bb9cff','#69e5d6'];
  const names = ['LAYOUT','COMPONENT','TYPE','MOTION','QA'];
  const glyphs = ['↖','↗','⌕','⌁','✳'];
  const agentRoot = document.getElementById('constructionAgents');
  const count = document.getElementById('constructionCount');
  const status = document.getElementById('constructionStatus');
  const prompt = document.getElementById('constructionPrompt');
  const svg = document.getElementById('constructionTrails');
  const polylines = [...svg.querySelectorAll('polyline')];
  const clamp = x => Math.max(0, Math.min(1, x));
  const lerp = (a,b,t) => a+(b-a)*t;
  const ease = x => { const p=clamp(x); return p*p*(3-2*p); };
  const hero = document.getElementById('top');
  const candidates = [];
  const agents = names.map((name, i) => {
    const el = document.createElement('div');
    el.className = 'construction-agent';
    el.style.setProperty('--agent', palettes[i]);
    el.innerHTML = `<div class="agent-pointer"><svg viewBox="0 0 28 35" aria-hidden="true"><path d="M2 2 L2 29 L9 22 L15 34 L21 31 L14 19 L26 17 Z"/></svg><span class="agent-tap"></span></div><span class="agent-tag">${name} <small>0${i+1}</small></span><span class="agent-hint"></span>`;
    const frame = document.createElement('div');
    frame.className='construction-selection';
    frame.style.setProperty('--agent',palettes[i]);
    frame.innerHTML='<i></i><i></i><i></i><i></i><span class="selection-type">frame / auto-layout</span>';
    agentRoot.append(frame,el);
    polylines[i].setAttribute('stroke',palettes[i]);
    return {el,frame,x:innerWidth*(.20+i*.13),y:innerHeight*(.24+i*.09),tx:0,ty:0,history:[],target:null,i,tag:el.querySelector('.agent-hint'),frameType:frame.querySelector('.selection-type')};
  });

  const spec = [
    ['#siteHeader', '.brand,.nav-link,.ist-clock,.header-cta'],
    ['#top', '.hero-eyebrow,.hero-title .hero-line,.hero-visual,.hero-bottom p,.hero-bottom a,.hero-footer>span'],
    ['#build','.build-kicker,.build-narrative h2,.build-body,.build-step-readout,.build-progress-track,.build-legend,.build-stage-hud,.build-browser,.build-stage-foot'],
    ['#about','.section-kicker,.intro-decoration,.intro-statement,.intro-copy p,.intro-copy a,.profile-facts>span,.verified-bio,.signal-line'],
    ['#work','.section-kicker,.work-heading h2,.work-heading p,.project-card .project-art,.project-art .art-topline,.ride-map,.ride-ui,.pilot-scene .node,.pilot-scene .node-wire,.nixi-panel,.nixi-graph,.project-art .art-index,.project-card .project-meta,.after-projects>span,.after-projects a'],
    ['#repositories','.section-kicker,.repositories-heading h2,.repositories-heading p,.source-links>a,.repo-card .repo-top,.repo-card .repo-art,.repo-card h3,.repo-card p,.repo-card .repo-footer,.repo-disclaimer'],
    ['.statement-band','.statement-band-inner>span'],
    ['#services','.section-kicker,.expertise-left h2,.expertise-left>p,.skill-cloud span,.accordion-item'],
    ['#journey','.section-kicker,.career-heading h2,.career-heading p,.career-heading a,.career-item,.career-certs'],
    ['.process-section','.section-kicker,.process-headline,.process-step'],
    ['#contact','.section-kicker,.contact-small,.contact-copy h2,.contact-desc,.contact-social a,.form-header,.contact-form label,.contact-form input,.contact-form textarea,.contact-form button,.footer-upper>* ,.footer>span']
  ];

  const sections = new Map();
  spec.forEach(([selector, query], sectionIndex) => {
    const section = document.querySelector(selector);
    if(!section) return;
    const list = [...section.querySelectorAll(query)].filter(el => !el.closest('.case-modal'));
    const current=[];
    list.forEach((el,idx) => {
      // Skip elements that are nested in another target, except when intentionally
      // building each line of the actual hero, or individual repository subparts.
      const node = {el,section,sectionIndex,index:idx,id:candidates.length,agent:idx%5,p:-1,top:0,left:0,rect:null,threshold:0,end:0,active:false};
      el.classList.add('site-construct-element');
      el.style.setProperty('--construct-progress','0');
      el.setAttribute('data-site-build-id',String(node.id));
      candidates.push(node);current.push(node);
    });
    sections.set(section,current);
  });
  count.textContent=`0 / ${candidates.length}`;
  root.classList.add('site-construction-on');
  // Override the previous one-way fade system only for the newly constructed
  // elements. Other content retains original entrance effects.
  candidates.forEach(n=>n.el.classList.add('is-visible'));

  const heroTargets = candidates.filter(n => n.section===hero || n.section.id==='siteHeader');
  const story = document.getElementById('build');
  const storyTargets = candidates.filter(n => n.section===story);
  let lastY=-1,lastW=0,lastH=0,lastTick=0,scrubbing=false,ticking=false,ready=true;
  let events=0;
  function recalc(){
    const vh=innerHeight;
    const documentY=scrollY;
    candidates.forEach(n=>{
      const r=n.el.getBoundingClientRect();
      n.top=r.top+documentY;
      n.left=r.left;
      n.width=r.width;
      n.height=r.height;
      // Individual targets in a row have staggered positions, so the cursors
      // actually visit DIFFERENT items instead of revealing them in one batch.
      n.threshold=n.top - vh*.89 + (n.index%5)*28;
      n.end=n.threshold + Math.max(400,Math.min(660,vh*.65));
    });
    lastW=innerWidth;lastH=innerHeight;
  }
  function progress(n,y){
    if(n.section===hero || n.section.id==='siteHeader'){
      // Pin the REAL hero for an entire viewport of scroll and build its
      // actual headings/nav/3D artwork in sequence.
      const visibleHero=heroTargets.filter(item => innerWidth>720 || !item.el.closest('#navLinks'));
      const idx=visibleHero.indexOf(n);
      if(idx<0) return 1; // off-canvas mobile navigation stays functional
      const start = 22 + idx*(innerWidth<=720?31:34);
      const end = start+Math.max(110,innerHeight*.20);
      return ease((y-start)/(end-start));
    }
    if(n.section===story){
      // Sticky studio is also constructed from actual page nodes; this section
      // retains its original detailed demonstration and native animations.
      const rect=story.getBoundingClientRect();
      const travel=Math.max(1,rect.height-innerHeight);
      const p=clamp(-rect.top/travel);
      const idx=storyTargets.indexOf(n);
      return ease((p-(idx*.032))/(Math.max(.10,1-storyTargets.length*.032)));
    }
    return ease((y-n.threshold)/(n.end-n.threshold));
  }
  function mark(n,p){
    if(Math.abs(p-n.p)<.005) return;
    n.p=p;
    n.el.style.setProperty('--construct-progress',p.toFixed(3));
    n.el.classList.toggle('construct-done',p>.999);
    n.el.classList.toggle('construct-building',p>.015&&p<.999);
    n.el.classList.toggle('construct-pending',p<.015);
  }
  function pretty(n){
    if(!n) return 'BUILD';
    const text=(n.el.innerText||n.el.getAttribute('aria-label')||'').trim().replace(/\s+/g,' ').slice(0,23).toUpperCase();
    return text || n.el.tagName.toLowerCase();
  }
  const buildLocator = (r,p,agentIndex) => {
    const w=Math.min(920,Math.max(24,r.width));
    const h=Math.min(700,Math.max(18,r.height));
    const t=clamp(p);
    // Follow the perimeter of an individual DOM element as it builds.
    let x,y;
    if(t<.30){x=lerp(0,w,t/.30);y=0;}
    else if(t<.53){x=w;y=lerp(0,h,(t-.30)/.23);}
    else if(t<.80){x=lerp(w,0,(t-.53)/.27);y=h;}
    else {x=0;y=lerp(h,0,(t-.80)/.20);}
    const tx=clamp((r.left+x)/Math.max(1,innerWidth))*innerWidth;
    const ty=clamp((r.top+y)/Math.max(1,innerHeight))*innerHeight;
    return {x:Math.max(8,Math.min(innerWidth-100,tx)),y:Math.max(12,Math.min(innerHeight-28,ty+agentIndex*2))};
  };
  let sceneState={active:[],done:0};
  function update(){
    const y=scrollY;
    if(innerWidth!==lastW||innerHeight!==lastH) recalc();
    const current=[];let done=0;
    for(const n of candidates){
      const p=progress(n,y);mark(n,p);
      if(p>.999)done++;
      // Consider only visible real nodes. Offscreen elements cannot attract cursors.
      if(p>.005 && p<.999){
        const r=n.el.getBoundingClientRect();
        if(r.bottom>-10&&r.top<innerHeight+10 && r.right>0&&r.left<innerWidth){
          n.rect=r;current.push(n);
        }
      }
    }
    count.textContent=`${String(done).padStart(2,'0')} / ${candidates.length}`;
    const nearHero = y < Math.max(100,hero.offsetHeight-innerHeight-30);
    prompt.classList.toggle('is-hidden',y>Math.max(80,innerHeight*.16));
    layer.classList.toggle('in-hero',nearHero);
    // Every cursor gets its own independent DOM target; never five cursors on
    // the same node. Assign by agent index, with nearest-active fallback.
    const used=new Set();
    agents.forEach((a,i)=>{
      const options=current.filter(n=>!used.has(n.id));
      let n=options.find(n=>n.agent===i);
      if(!n && options.length) n=options[(i*7+Math.floor(y/130))%options.length];
      if(!n){
        // In sparse parts of a page, collaborators keep inspecting already
        // assembled live elements instead of disappearing or random drifting.
        const nearby=candidates.filter(v=>{
          if(v.agent!==i || v.p<.96)return false;
          const r=v.el.getBoundingClientRect();
          return r.bottom>25&&r.top<innerHeight-30&&r.width>0&&r.right>0&&r.left<innerWidth;
        });
        if(nearby.length){n=nearby[Math.floor(y/240+i)%nearby.length];n.rect=n.el.getBoundingClientRect();n.inspect=true;}
      }
      if(n){
        used.add(n.id);
        a.target=n;
        const r=n.rect||n.el.getBoundingClientRect();
        const point=buildLocator(r,n.p,i);
        a.tx=point.x;a.ty=point.y;
        a.frame.style.display='block';
        a.frame.style.left=r.left+'px';a.frame.style.top=r.top+'px';
        a.frame.style.width=r.width+'px';a.frame.style.height=r.height+'px';
        a.frame.style.setProperty('--frame-progress',n.p.toFixed(3));
        a.frameType.textContent=`${n.el.tagName.toLowerCase()} / ${String(n.id).padStart(3,'0')}`;
        a.tag.textContent=(n.p>.96?'CHECK / ':'BUILD / ')+pretty(n);
        a.el.classList.add('active');
      } else {
        a.target=null;a.frame.style.display='none';
        a.tag.textContent='SELECTING NEXT ELEMENT';
        a.el.classList.toggle('active', y<document.documentElement.scrollHeight-innerHeight-35);
        a.tx=Math.max(18,Math.min(innerWidth-130,(.11+.16*i)*innerWidth + Math.sin(y/110+i)*28));
        a.ty=Math.max(20,Math.min(innerHeight-40,(.27+.10*i)*innerHeight + Math.cos(y/190+i)*26));
      }
    });
    sceneState={active:current,done};
    status.textContent=current.length ? 'LIVE BUILD / CONSTRUCTING REAL ELEMENTS' : 'LIVE BUILD / SCROLL TO CONTINUE';
    lastY=y;
  }
  function renderCursors(){
    let moving=false;
    agents.forEach(a=>{
      const dx=a.tx-a.x,dy=a.ty-a.y;
      a.x+=dx*.17;a.y+=dy*.17;
      moving ||= Math.abs(dx)+Math.abs(dy)>1.2;
      a.el.style.transform=`translate3d(${a.x.toFixed(1)}px,${a.y.toFixed(1)}px,0)`;
      if(moving){
        a.history.push([a.x,a.y]);
        if(a.history.length>11)a.history.shift();
        polylines[a.i].setAttribute('points',a.history.map(pt=>pt.map(v=>v.toFixed(1)).join(',')).join(' '));
      }
    });
    if(moving){requestAnimationFrame(renderCursors);}
    else{ticking=false;}
  }
  function schedule(){
    if(!ready)return;
    if(!scrubbing){
      scrubbing=true;
      requestAnimationFrame(()=>{
        scrubbing=false;update();
        if(!ticking){ticking=true;requestAnimationFrame(renderCursors);}
      });
    }
  }
  function refresh(){recalc();schedule();}
  recalc();update();requestAnimationFrame(()=>{ticking=true;renderCursors();});
  addEventListener('scroll',schedule,{passive:true});
  addEventListener('resize',refresh,{passive:true});
  addEventListener('pageshow',refresh);
  // ResizeObserver handles line-wrap and dynamic accordion layout without
  // relying on a heavy animation library or fixed magic pixel positions.
  if('ResizeObserver' in window){
    let timer=0;
    const ro = new ResizeObserver(()=>{if(timer)return;timer=requestAnimationFrame(()=>{timer=0;recalc();schedule();});});
    [hero,story,...sections.keys()].filter(Boolean).forEach(section=>ro.observe(section));
  }
  // Loading deep anchor URLs: wait for browser restoration, then rebuild state.
  setTimeout(refresh,140);
  setTimeout(refresh,1050);
  // Export a tiny, read-only test hook for automated QA without polluting UI.
  window.__siteConstructionQA=()=>({total:candidates.length,built:sceneState.done,active:sceneState.active.length,targets:candidates.map(n=>({id:n.id,name:n.el.className,progress:n.p})),cursors:agents.map(a=>({active:!!a.target,target:a.target?.id??null,x:a.x,y:a.y}))});
})();
