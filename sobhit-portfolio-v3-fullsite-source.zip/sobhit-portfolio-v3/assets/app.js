/* Premium portfolio interactions — dependency-free. */
(() => {
  'use strict';
  const CONFIG = {
    // REQUIRED before production: supply an email address to enable mailto enquiry.
    contactEmail: 'sobhitjadoun@gmail.com',
    // Profile links were matched to the public URLs supplied by the owner.
    introDurationMs: 1150
  };
  const $ = (selector,scope=document)=>scope.querySelector(selector);
  const $$ = (selector,scope=document)=>[...scope.querySelectorAll(selector)];
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const toastEl=$('#toast'); let toastTimer;
  function toast(message){toastEl.textContent=message;toastEl.classList.add('is-on');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove('is-on'),4500);}
  $('#year').textContent=String(new Date().getFullYear());
  function setTime(){const clock=$('#istClock');if(!clock)return;try{clock.textContent='IND / '+new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'Asia/Kolkata'}).format(new Date())+' IST';}catch(_){clock.textContent='IND / IST';}}
  setTime();setInterval(setTime,60_000);
  // Preloader: intentionally short, skippable, never an accessibility blocker.
  const loader=$('#loader'),skip=$('#loaderSkip'),meter=$('#loaderFill'),percent=$('#loaderPercent');let closed=false;
  function closeLoader(){if(closed)return;closed=true;loader.classList.add('is-done');loader.setAttribute('aria-hidden','true');$$('[data-animate="title"]').forEach(el=>el.classList.add('is-visible'));$$('.hero [data-reveal]').forEach(el=>el.classList.add('is-visible'));setTimeout(()=>loader.remove(),1200);}
  skip.addEventListener('click',closeLoader);
  if(reduced){closeLoader();}else{const t0=performance.now(),duration=CONFIG.introDurationMs;const tick=now=>{if(closed)return;let progress=Math.min(1,(now-t0)/duration);let eased=1-Math.pow(1-progress,2.4);meter.style.width=(eased*100).toFixed(2)+'%';percent.textContent=String(Math.round(eased*100)).padStart(2,'0');if(progress<1)requestAnimationFrame(tick);else setTimeout(closeLoader,120);};requestAnimationFrame(tick);}

  // Viewport entrances: one observer + subtle staggering.
  const revealables=$$('[data-reveal]');
  if('IntersectionObserver' in window && !reduced){
    const io=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target);}})},{threshold:.09,rootMargin:'0px 0px -25px 0px'});
    revealables.forEach((el,i)=>{if(el.closest('.process-steps'))el.style.transitionDelay=((i%4)*.07)+'s';io.observe(el);});
  }else{revealables.forEach(el=>el.classList.add('is-visible'));}

  // Scroll progress, header appearance, active section navigation, and soft parallax.
  const header=$('#siteHeader'),bar=$('#pageProgress'),visual=$('.hero-visual');
  let scrollY=0,scrollTicking=false;
  function onScroll(){scrollY=window.scrollY;header.classList.toggle('scrolled',scrollY>32);const max=Math.max(1,document.documentElement.scrollHeight-innerHeight);bar.style.width=Math.min(100,scrollY/max*100)+'%';if(visual && !reduced && innerWidth>720 && scrollY<1100){visual.style.translate=`0 ${Math.min(130,scrollY*.14)}px`;}scrollTicking=false;}
  addEventListener('scroll',()=>{if(!scrollTicking){scrollTicking=true;requestAnimationFrame(onScroll);}},{passive:true});onScroll();
  if('IntersectionObserver' in window){const sections=['build','work','about','repositories','services','contact'].map(id=>document.getElementById(id));const links=$$('.nav-link');const current=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){links.forEach(link=>link.classList.toggle('is-active',link.getAttribute('href')==='#'+entry.target.id));}})},{rootMargin:'-35% 0px -55% 0px'});sections.forEach(el=>current.observe(el));}

  // Mobile menu with real aria-expanded and close-on-navigation behavior.
  const menu=$('#mobileMenu'),nav=$('#navLinks');
  function setMenu(isOpen){nav.classList.toggle('open',isOpen);menu.setAttribute('aria-expanded',String(isOpen));menu.setAttribute('aria-label',isOpen?'Close navigation':'Open navigation');const bars=$$('span',menu);if(bars[0])bars[0].style.transform=isOpen?'translateY(4px) rotate(45deg)':'';if(bars[1])bars[1].style.transform=isOpen?'translateY(-4px) rotate(-45deg)':'';}
  menu.addEventListener('click',()=>setMenu(!nav.classList.contains('open')));
  $$('.nav-link',nav).forEach(link=>link.addEventListener('click',()=>setMenu(false)));
  addEventListener('resize',()=>{if(innerWidth>720)setMenu(false);},{passive:true});

  // Pointer-follow cursor and gentle magnetic CTAs; disabled on touch/reduced-motion.
  if(matchMedia('(pointer:fine)').matches && !reduced){const dot=$('#cursorDot'),ring=$('#cursorRing');let mx=-100,my=-100,rx=-100,ry=-100;addEventListener('pointermove',e=>{mx=e.clientX;my=e.clientY;},{passive:true});const loop=()=>{rx+=(mx-rx)*.18;ry+=(my-ry)*.18;dot.style.transform=`translate3d(${mx}px,${my}px,0)`;ring.style.transform=`translate3d(${rx}px,${ry}px,0)`;requestAnimationFrame(loop);};requestAnimationFrame(loop);$$('a, button, [role="button"]').forEach(el=>{el.addEventListener('pointerenter',()=>ring.classList.add('is-hover'));el.addEventListener('pointerleave',()=>ring.classList.remove('is-hover'));});$$('.magnetic').forEach(el=>{el.addEventListener('pointermove',e=>{const r=el.getBoundingClientRect();const x=(e.clientX-(r.left+r.width/2))*.12,y=(e.clientY-(r.top+r.height/2))*.12;el.style.translate=`${x}px ${y}px`;});el.addEventListener('pointerleave',()=>el.style.translate='0 0');});}

  // Accessible accordion: one pane at a time; click to collapse an open pane.
  $$('.accordion-button').forEach(button=>button.addEventListener('click',()=>{const item=button.closest('.accordion-item');const open=item.classList.contains('is-open');$$('.accordion-item').forEach(other=>{other.classList.remove('is-open');$('.accordion-button',other).setAttribute('aria-expanded','false');$('.accordion-sign',other).textContent='+';});if(!open){item.classList.add('is-open');button.setAttribute('aria-expanded','true');$('.accordion-sign',item).textContent='−';}}));

  const projects={
    ridevoyage:{index:'01 / 03',name:'RideVoyage',status:'IN DEVELOPMENT',description:'A rider-focused platform concept bringing together routes, solo and group rides, community features and practical travel planning. The challenge is turning a complex set of trip-planning tools into an intuitive, mobile-friendly experience.',tags:['PRODUCT THINKING','FRONTEND UX','INTERACTIVE MAPS','RESPONSIVE UI']},
    workpilot:{index:'02 / 03',name:'WorkPilot',status:'IN DEVELOPMENT',description:'A WordPress workflow automation product centered on everyday publishing and site-management tasks. Its interface explores command-driven navigation, node-based workflows, safe bulk editing and clear feedback after actions.',tags:['WORDPRESS','PLUGIN UX','WORKFLOW DESIGN','JAVASCRIPT']},
    nixiseo:{index:'03 / 03',name:'NixiSEO',status:'IN DEVELOPMENT',description:'An SEO-focused WordPress plugin project exploring practical audits, search optimization workflows and a dashboard that helps site owners understand findings and prioritize changes.',tags:['PLUGIN UI','SEO WORKFLOWS','DASHBOARDS','WORDPRESS']}
  };
  const modal=$('#caseModal'),closeCase=$('#caseClose');let restoreFocus=null;
  function openCase(key){const item=projects[key];if(!item)return;restoreFocus=document.activeElement;$('#caseTitle').textContent=item.name;$('#caseIndex').textContent=item.index;$('#caseStatus').textContent=item.status;$('#caseDescription').textContent=item.description;$('#caseTags').replaceChildren(...item.tags.map(v=>{const s=document.createElement('span');s.textContent=v;return s;}));modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('no-scroll');closeCase.focus();}
  function dismissCase(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('no-scroll');if(restoreFocus && restoreFocus.focus)restoreFocus.focus();}
  $$('.project-card').forEach(card=>{card.addEventListener('click',()=>openCase(card.dataset.project));card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openCase(card.dataset.project);}});});closeCase.addEventListener('click',dismissCase);$('.case-modal-backdrop').addEventListener('click',dismissCase);$('#caseNext').addEventListener('click',dismissCase);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){dismissCase();setMenu(false);}if(e.key==='Tab' && modal.classList.contains('is-open')){const foc=$$('a[href], button',modal).filter(el=>getComputedStyle(el).display!=='none');if(!foc.length)return;const first=foc[0],last=foc[foc.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});

  // External profile placeholders are not allowed to mislead visitors.
  $$('[data-placeholder-link]').forEach(link=>link.addEventListener('click',e=>{e.preventDefault();toast('Add your personal '+link.textContent.replace('↗','').trim()+' profile URL in index.html before publishing.');}));

  async function copyText(value){
    try{if(navigator.clipboard && window.isSecureContext){await navigator.clipboard.writeText(value);return true;}}
    catch(_){}
    const txt=document.createElement('textarea');txt.value=value;txt.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(txt);txt.select();let copied=false;try{copied=document.execCommand('copy');}catch(_){}txt.remove();return copied;
  }
  const form=$('#contactForm');form.addEventListener('submit',async e=>{
    e.preventDefault();if(!form.reportValidity())return;
    const data=new FormData(form),name=String(data.get('name')).trim(),email=String(data.get('email')).trim(),message=String(data.get('message')).trim();
    const subject=`Portfolio enquiry from ${name}`;
    const body=`Name: ${name}\nEmail: ${email}\n\nProject idea:\n${message}`;
    if(CONFIG.contactEmail){window.location.href=`mailto:${encodeURIComponent(CONFIG.contactEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;toast('Your mail app is opening with the enquiry. Review and send it there.');return;}
    const success=await copyText(`${subject}\n\n${body}`);
    toast(success?'Enquiry copied. This demo has no recipient set, so nothing was sent.':'Demo only: no recipient is configured. Add contactEmail in assets/app.js before launch.');
    if(success){$('#formSubmitText').textContent='ENQUIRY COPIED ✓';setTimeout(()=>$('#formSubmitText').textContent='PREPARE ENQUIRY',3000);}
  });
})();
