# Sobhit Jadoun / Creative Developer Portfolio — V2

A standalone, responsive HTML/CSS/JavaScript portfolio with native WebGL 3D art, custom scroll-controlled collaborative build animation, interactive work case studies and real public GitHub project links. **The original V1 hero, RideVoyage, WorkPilot, NixiSEO, services accordion, process and contact section are preserved.**

## Quick start

Open `index.html` or run:

```bash
cd hex-portfolio
python3 -m http.server 8080
```

Visit `http://localhost:8080` and scroll **past the lime ticker** to experience the pinned five-cursor building choreography. Scrolling backward reverses the simulated construction. The 3D hero can be dragged with a mouse/pointer. A responsive, standalone browser preview is also supplied separately.

## Source files

- `index.html`: preserved original sections + construction animation + 6 public GitHub repository spotlights.
- `assets/styles.css`: all responsive visuals, blue selection bounds, cursor labels and artwork.
- `assets/builder.js`: deterministic, 4-phase, scroll-driven and reversible builder choreography, with 5 independent virtual cursors and progress readout.
- `assets/webgl.js`: preserved original WebGL interactive sculpture.
- `assets/app.js`: preserved core animations, navigation, modal, accordion, contact and cursor interactions; now configured with public contact address from GitHub README.
- `IMPLEMENTATION_PLAN.md`: requirements and production readiness tasks.

## Verified public sources (checked November 6, 2026)

- Main GitHub: https://github.com/SobhitJadoun?tab=repositories
- Second GitHub: https://github.com/Hackertrackersj
- LinkedIn: https://www.linkedin.com/in/sobhitjadoun
- GitHub profile README: `SobhitJadoun/SobhitJadoun` (lists contact email, core technology, and examples of work)
- Selected repository metadata and readmes: `omninox-site-toolkit`, `Trip-Diary`, `Online-store`, `Mavolo`, `B24U_Blood24You_CorePHP`, `smb-scanner`.

### Accuracy policy

The repository section links to visible public code; titles and descriptions are deliberately conservative. No GitHub stars/followers/contribution totals or completion claims are invented. The second account features early security tooling; repository attribution may be shared with other authors. The original three visual case studies remain labeled "In Development" until production results can be verified.

### Contact

The `contactEmail` setting in `assets/app.js` is set to `sobhitjadoun@gmail.com` because that address is printed in the public GitHub profile README. The form **opens the visitor's mail client with a composed message**; it does not submit to a server or silently send the email. Add a real backend or service to accept messages on-site. Verify this address is still desired before launch.

### Accessibility / performance

The collaborative cursor scene is decorative and pointer-events-free. The textual progress readout complements the visuals. `prefers-reduced-motion` disables the pinned scroll requirement and shows a completed static rendering. The original WebGL fallback remains available. Keyboard menu and case study drawer remain functional.

### Deploy

Static host: GitHub Pages, Netlify, Cloudflare Pages or Vercel. Upload the `hex-portfolio/` folder. There are no package dependencies, build tasks or API keys.

## Version 3 — full-site multi-cursor construction (6 Nov 2026)

The cursor construction effect now runs **throughout the actual site** rather than just on the small studio mockup. It uses `assets/site-construction.js`, which maps real header, hero, text, project artwork, GitHub repository cards, skills, timeline, contact form and footer elements to scroll-driven progress. It currently animates **155 targeted real DOM elements**. Five separate simulated designer cursors each acquire a unique active element; they draw colored outlines with handles and labels, leave cursor trails, and reveal content incrementally. Scrolling back reverses the reveal.

The hero is deliberately pinned for approximately one additional viewport while its real headings, navigation and interactive WebGL sculpture are assembled by scrolling. The status in the lower right shows the number of completed elements. Some older 'LIVE BUILD' studio demo content is preserved, but it is **not** the only place the new animation runs.

### Run locally

Open `index.html` in a modern browser. If browser security policies disallow local script execution, run a static web server in this folder: `python -m http.server 8000` and open `http://localhost:8000`.

### How to customize

- `assets/site-construction.js`: change `spec` to select which real elements build; adjust the scroll thresholds and cursor names/colors.
- `assets/styles.css`: inspect the `FULL-SITE COLLABORATIVE BUILD` section for selection handles, trails, grid and cursor visual styles.
- `assets/webgl.js`: original interactive 3D sculpture, unchanged.
- `assets/builder.js`: preserved legacy studio build demonstration.
- `index.html`: preserved personal projects, GitHub, LinkedIn and contact information.

### Accessibility and truthful limitations

- Reduced-motion users receive the normal full website with no construction overlay, no hidden text, and no sticky hero.
- These are simulated cursors, **not** other visitors' actual mice. No multi-user networking is installed.
- This reproduces the reference video's *observable visual behavior*, not the original proprietary animation code or frame-identical timing.
- The contact form opens the user's mail client and does not send directly from a server.

### QA

Checked in Chromium at desktop, tablet and mobile widths: 155 real targets, full-site progress, scroll-reversible reveals, preserved project modal and six repository links, functional contact fields, WebGL hero rendering, no JavaScript exceptions, no horizontal page overflow. Cross-browser and real-device QA remain appropriate before release.
